
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_svg/flutter_svg.dart';

void main() {
  runApp(BankApp());
}

class BankApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IDFC-style Bank (Mock)',
      theme: ThemeData(
        primaryColor: Color(0xFF3D0066),
        colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Color(0xFFE80071)),
        scaffoldBackgroundColor: Colors.white,
      ),
      initialRoute: '/splash',
      routes: {
        '/splash': (_) => SplashScreen(),
        '/welcome': (_) => WelcomeScreen(),
        '/login': (_) => MobileLoginScreen(),
        '/otp': (_) => OtpScreen(),
        '/set_mpin': (_) => SetMpinScreen(),
        '/mpin': (_) => MpinLoginScreen(),
        '/home': (_) => HomeScreen(),
        '/account': (_) => AccountScreen(),
        '/transactions': (_) => TransactionsScreen(),
        '/quick': (_) => QuickActionsScreen(),
        '/settings': (_) => SettingsScreen(),
        // placeholders mapped below dynamically
      },
    );
  }
}

class SplashScreen extends StatefulWidget { @override _SplashScreenState createState() => _SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen> {
  @override void initState(){
    super.initState();
    Future.delayed(Duration(seconds:2), ()=> Navigator.pushReplacementNamed(context, '/welcome'));
  }
  @override Widget build(BuildContext context){
    return Scaffold(body: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF3D0066), Color(0xFFE80071)])), child: Center(child: SvgPicture.asset('assets/logo.svg', width:140))));
  }
}

class WelcomeScreen extends StatelessWidget {
  @override Widget build(BuildContext context){
    return Scaffold(body: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Text('Banking that fits you', style: TextStyle(fontSize:24, fontWeight: FontWeight.bold)), SizedBox(height:12), Text('Fast, Secure, Personal', style: TextStyle(color: Colors.grey[700])), SizedBox(height:24), ElevatedButton(onPressed: ()=> Navigator.pushReplacementNamed(context, '/login'), style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3D0066), minimumSize: Size.fromHeight(56)), child: Text('Get Started'))])));
  }
}

class MobileLoginScreen extends StatelessWidget {
  final TextEditingController phone = TextEditingController();
  @override Widget build(BuildContext context){
    return Scaffold(body: SafeArea(child: Padding(padding: EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[Align(alignment: Alignment.centerRight, child: SvgPicture.asset('assets/logo.svg', width:80)), SizedBox(height:30), Text('Welcome back, Swapnil', style: TextStyle(fontSize:22, fontWeight: FontWeight.bold)), SizedBox(height:8), Text('Login with your mobile number', style: TextStyle(color: Colors.grey[600])), SizedBox(height:20), Row(children:[Container(padding: EdgeInsets.symmetric(horizontal:12, vertical:14), decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade300), borderRadius: BorderRadius.circular(8)), child: Text('+91')), SizedBox(width:12), Expanded(child: TextField(controller: phone, keyboardType: TextInputType.phone, decoration: InputDecoration(hintText: 'Enter mobile number', border: OutlineInputBorder()))) ]), SizedBox(height:20), ElevatedButton(style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(56), backgroundColor: Color(0xFF3D0066)), onPressed: ()=> Navigator.pushNamed(context, '/otp', arguments: {'phone': phone.text}), child: Text('CONTINUE'))])));
  }
}

class OtpScreen extends StatelessWidget{
  @override Widget build(BuildContext context){
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    final phone = args!=null && args.containsKey('phone')? args['phone'] : '';
    return Scaffold(appBar: AppBar(backgroundColor: Color(0xFF3D0066), elevation:0), body: Padding(padding: EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[SizedBox(height:20), Text('Enter OTP', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)), SizedBox(height:8), Text('We sent a 6-digit code to ${phone}', style: TextStyle(color: Colors.grey[600])), SizedBox(height:20), TextField(maxLength:6, keyboardType: TextInputType.number, decoration: InputDecoration(hintText: 'Enter OTP', border: OutlineInputBorder())), SizedBox(height:20), ElevatedButton(style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(56), backgroundColor: Color(0xFF3D0066)), onPressed: ()=> Navigator.pushReplacementNamed(context, '/home'), child: Text('VERIFY')), SizedBox(height:12), TextButton(onPressed: (){}, child: Text('Resend OTP'))])));
  }
}

class SetMpinScreen extends StatelessWidget{ @override Widget build(BuildContext context){ return Scaffold(body: Padding(padding: EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[SizedBox(height:40), Text('Create MPIN', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)), SizedBox(height:12), TextField(maxLength:4, keyboardType: TextInputType.number, decoration: InputDecoration(hintText:'Enter 4-digit MPIN', border: OutlineInputBorder())), SizedBox(height:12), TextField(maxLength:4, keyboardType: TextInputType.number, decoration: InputDecoration(hintText:'Confirm MPIN', border: OutlineInputBorder())), SizedBox(height:20), ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3D0066), minimumSize: Size.fromHeight(56)), onPressed: ()=> Navigator.pushReplacementNamed(context, '/mpin'), child: Text('SET MPIN'))]))); } }

class MpinLoginScreen extends StatelessWidget{ @override Widget build(BuildContext context){ return Scaffold(body: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Text('Enter MPIN', style: TextStyle(fontSize:20, fontWeight: FontWeight.bold)), SizedBox(height:12), TextField(maxLength:4, keyboardType: TextInputType.number, decoration: InputDecoration(hintText:'Enter MPIN', border: OutlineInputBorder())), SizedBox(height:20), ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3D0066), minimumSize: Size.fromHeight(56)), onPressed: ()=> Navigator.pushReplacementNamed(context, '/home'), child: Text('UNLOCK')), SizedBox(height:12), TextButton(onPressed: ()=> Navigator.pushNamed(context, '/login'), child: Text('Use OTP instead'))]))); } }

class HomeScreen extends StatefulWidget{ @override _HomeScreenState createState()=> _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  List txns = [];
  Map account = {};
  @override void initState(){ super.initState(); loadAssets(); }
  Future<void> loadAssets() async {
    try { final s = await rootBundle.loadString('assets/transactions.json'); txns = json.decode(s) as List; } catch(e){ txns = []; }
    try { final a = await rootBundle.loadString('assets/account_info.json'); account = json.decode(a) as Map; } catch(e){ account = {}; }
    setState((){});
  }
  @override Widget build(BuildContext context){
    final name = account['name'] ?? 'Swapnil Dilip Wankhade';
    final accNo = account['account_number'] ?? '10108755380';
    return Scaffold(body: Stack(children:[ Container(height:220, decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF3D0066), Color(0xFFE80071)]))), SafeArea(child: Padding(padding: EdgeInsets.symmetric(horizontal:16), child: Column(children:[ SizedBox(height:12), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[ Text('IDFC Bank', style: TextStyle(color: Colors.white, fontSize:20, fontWeight: FontWeight.bold)), CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person, color: Color(0xFF3D0066))) ]), SizedBox(height:24), Container(margin: EdgeInsets.only(top:40), child: Card(elevation:6, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text('Available Balance', style: TextStyle(color: Colors.grey[600])), SizedBox(height:8), Text('₹80,000', style: TextStyle(fontSize:32, fontWeight: FontWeight.bold)), SizedBox(height:8), Text('Account: $accNo', style: TextStyle(color: Colors.grey[600])), SizedBox(height:12), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[ Column(children:[ CircleAvatar(backgroundColor: Color(0xFF3D0066), child: Icon(Icons.send, color: Colors.white)), SizedBox(height:4), Text('Send') ]), Column(children:[ CircleAvatar(backgroundColor: Color(0xFF3D0066), child: Icon(Icons.call_received, color: Colors.white)), SizedBox(height:4), Text('Receive') ]), Column(children:[ CircleAvatar(backgroundColor: Color(0xFF3D0066), child: Icon(Icons.picture_as_pdf, color: Colors.white)), SizedBox(height:4), Text('Statement') ]), Column(children:[ CircleAvatar(backgroundColor: Color(0xFF3D0066), child: Icon(Icons.more_horiz, color: Colors.white)), SizedBox(height:4), Text('More') ]) ])) )), SizedBox(height:16), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[ Text('Recent Transactions', style: TextStyle(fontWeight: FontWeight.bold)), TextButton(onPressed: ()=> Navigator.pushNamed(context, '/transactions'), child: Text('View all')) ]), SizedBox(height:8), Expanded(child: txns.isEmpty? Center(child: CircularProgressIndicator()): ListView.builder(itemCount: txns.length<3? txns.length:3, itemBuilder: (context,i){ final item = txns[i]; final amt = item['amount'] as num; final isDebit = amt<0; return ListTile(leading: CircleAvatar(backgroundColor: isDebit? Color(0xFFE80071): Color(0xFF2E7D32), child: Icon(isDebit? Icons.arrow_downward: Icons.arrow_upward, color: Colors.white)), title: Text(item['description'] ?? ''), subtitle: Text(item['date'] ?? ''), trailing: Text('₹${amt.abs()}', style: TextStyle(color: isDebit? Color(0xFFE80071): Color(0xFF2E7D32), fontWeight: FontWeight.bold)), ); })) ]))) ])); } }

class AccountScreen extends StatelessWidget{ @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text('Account'), backgroundColor: Color(0xFF3D0066)), body: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Card(elevation:4, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ FutureBuilder<String>(future: rootBundle.loadString('assets/account_info.json'), builder:(c,s){ if(!s.hasData) return Text('Swapnil Dilip Wankhade', style: TextStyle(fontWeight: FontWeight.bold)); try{ final a = json.decode(s.data!) as Map; return Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text(a['name'] ?? 'Swapnil Dilip Wankhade', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:8), Text('Account No: ${a['account_number'] ?? '10108755380'}', style: TextStyle(color: Colors.grey[600])), SizedBox(height:12), Text('Available Balance', style: TextStyle(color: Colors.grey[600])), Text('₹80,000', style: TextStyle(fontSize:28, fontWeight: FontWeight.bold)), SizedBox(height:12), ElevatedButton(onPressed: (){}, style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3D0066)), child: Text('Download Statement')) ]); }catch(e){ return Text('Swapnil Dilip Wankhade', style: TextStyle(fontWeight: FontWeight.bold)); } })) ])) ])); } }

class TransactionsScreen extends StatefulWidget{ @override _TransactionsScreenState createState()=> _TransactionsScreenState(); }
class _TransactionsScreenState extends State<TransactionsScreen>{ List txns = []; @override void initState(){ super.initState(); load(); } Future<void> load() async { try{ final s = await rootBundle.loadString('assets/transactions.json'); txns = json.decode(s) as List; }catch(e){ txns = []; } setState((){}); } @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text('Transactions'), backgroundColor: Color(0xFF3D0066)), body: txns.isEmpty? Center(child:CircularProgressIndicator()): ListView.builder(itemCount: txns.length, itemBuilder: (context,i){ final item = txns[i]; final amt = item['amount'] as num; final isDebit = amt<0; return Container(padding: EdgeInsets.all(12), margin: EdgeInsets.symmetric(horizontal:12, vertical:8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow:[BoxShadow(color: Colors.grey.withOpacity(0.06), blurRadius:6, offset: Offset(0,4))]), child: Row(children:[ CircleAvatar(backgroundColor: isDebit? Color(0xFFE80071): Color(0xFF2E7D32), child: Icon(isDebit? Icons.arrow_downward: Icons.arrow_upward, color: Colors.white)), SizedBox(width:12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text(item['description'] ?? '', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height:4), Text(item['date'] ?? '', style: TextStyle(color: Colors.grey[600])) ])), Text('₹${amt.abs()}', style: TextStyle(color: isDebit? Color(0xFFE80071): Color(0xFF2E7D32), fontWeight: FontWeight.bold)) ])); })); } }

class QuickActionsScreen extends StatelessWidget{ @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text('Quick Actions'), backgroundColor: Color(0xFF3D0066)), body: Padding(padding: EdgeInsets.all(16), child: GridView.count(crossAxisCount:2, childAspectRatio:1.2, children:[ _tile(Icons.send,'Send Money'), _tile(Icons.qr_code,'Scan & Pay'), _tile(Icons.payment,'Bill Pay'), _tile(Icons.refresh,'Recharge') ]))); } Widget _tile(IconData ic, String t)=> Card(child: InkWell(onTap: (){}, child: Center(child: Column(mainAxisSize:MainAxisSize.min, children:[CircleAvatar(backgroundColor: Color(0xFF3D0066), child: Icon(ic,color:Colors.white)), SizedBox(height:8), Text(t)])))) ; }

class SettingsScreen extends StatelessWidget{ @override Widget build(BuildContext context){ return Scaffold(appBar: AppBar(title: Text('Settings'), backgroundColor: Color(0xFF3D0066)), body: ListView(children:[ ListTile(title: Text('Profile'), trailing: Icon(Icons.chevron_right)), ListTile(title: Text('Security'), trailing: Icon(Icons.chevron_right)), ListTile(title: Text('Help & Support'), trailing: Icon(Icons.chevron_right)), ListTile(title: Text('Logout'), trailing: Icon(Icons.exit_to_app)) ])); } }

// Placeholder screens 11-46

class Screen11 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Splash Screen 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Splash Screen 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Splash Screen 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen12 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Welcome Slider 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Welcome Slider 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Welcome Slider 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen13 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Mobile Login 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Mobile Login 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Mobile Login 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen14 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('OTP Verification 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('OTP Verification 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for OTP Verification 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen15 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Set MPIN 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Set MPIN 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Set MPIN 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen16 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('MPIN Login 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('MPIN Login 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for MPIN Login 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen17 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Account Summary'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Account Summary', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Account Summary. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen18 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Balance Graph'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Balance Graph', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Balance Graph. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen19 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Download Statement'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Download Statement', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Download Statement. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen20 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Statement Month Selector'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Statement Month Selector', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Statement Month Selector. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen21 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('e-Passbook View'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('e-Passbook View', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for e-Passbook View. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen22 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('All Transactions List'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('All Transactions List', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for All Transactions List. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen23 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Transaction Filters'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Transaction Filters', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Transaction Filters. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen24 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Transaction Details'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Transaction Details', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Transaction Details. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen25 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Salary Detail'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Salary Detail', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Salary Detail. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen26 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Cash Withdrawal Detail'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Cash Withdrawal Detail', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Cash Withdrawal Detail. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen27 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('UPI Transactions'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('UPI Transactions', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for UPI Transactions. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen28 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Statement Export'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Statement Export', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Statement Export. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen29 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Send Money'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Send Money', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Send Money. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen30 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Request Money'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Request Money', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Request Money. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen31 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Enter UPI PIN'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Enter UPI PIN', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Enter UPI PIN. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen32 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Payment Success'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Payment Success', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Payment Success. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen33 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Payment Failed'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Payment Failed', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Payment Failed. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen34 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Debit Card Overview'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Debit Card Overview', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Debit Card Overview. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen35 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Card Settings'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Card Settings', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Card Settings. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen36 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('ATM Limit Setup'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('ATM Limit Setup', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for ATM Limit Setup. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen37 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Block Reissue Card'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Block Reissue Card', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Block Reissue Card. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen38 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Profile Page'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Profile Page', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Profile Page. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen39 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Edit Profile'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Edit Profile', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Edit Profile. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen40 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Notifications Settings'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Notifications Settings', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Notifications Settings. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen41 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Manage Devices'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Manage Devices', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Manage Devices. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen42 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Help Support'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Help Support', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Help Support. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen43 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Logout Screen'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Logout Screen', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Logout Screen. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen44 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Loan Offer Page'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Loan Offer Page', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Loan Offer Page. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen45 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('FD Summary'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('FD Summary', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for FD Summary. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen46 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Rewards Page'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Rewards Page', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Rewards Page. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen47 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Theme Settings'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Theme Settings', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Theme Settings. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen48 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Refer Earn'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Refer Earn', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Refer Earn. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen49 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('KYC Update'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('KYC Update', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for KYC Update. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen50 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Offers Banner'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Offers Banner', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Offers Banner. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen51 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Notifications Popup'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Notifications Popup', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Notifications Popup. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen52 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Accounts List'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Accounts List', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Accounts List. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen53 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Account Details'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Account Details', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Account Details. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen54 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Quick Actions 2'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Quick Actions 2', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Quick Actions 2. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen55 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('More Screen'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('More Screen', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for More Screen. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}


class Screen56 extends StatelessWidget{
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text('Extra Screen'), backgroundColor: Color(0xFF3D0066)),
      body: Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(Icons.dashboard, size:64, color: Color(0xFF3D0066)), SizedBox(height:16), Text('Extra Screen', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), SizedBox(height:8), Text('Placeholder for Extra Screen. Use Figma to replace with final UI.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[700]))])),
    );
  }
}
